package com.travelAgency;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TravelAgencyApplicationTests {

	@Test
	void contextLoads() {
	}

}
