package com.travelAgency;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ActivityTest {
    private Activity activity;

    @BeforeEach
    public void setUp() {
        // Create an Activity instance for testing
        activity = new Activity("Hiking", "Enjoy a scenic hike", 50.0, 20);
    }

    @Test
    public void testGetName() {
        assertEquals("Hiking", activity.getName());
    }

    @Test
    public void testSetName() {
        activity.setName("Sightseeing");
        assertEquals("Sightseeing", activity.getName());
    }

    @Test
    public void testGetDescription() {
        assertEquals("Enjoy a scenic hike", activity.getDescription());
    }

    @Test
    public void testSetDescription() {
        activity.setDescription("Explore the beautiful sights");
        assertEquals("Explore the beautiful sights", activity.getDescription());
    }

    @Test
    public void testGetCost() {
        assertEquals(50.0, activity.getCost(), 0.01);
    }

    @Test
    public void testSetCost() {
        activity.setCost(40.0);
        assertEquals(40.0, activity.getCost(), 0.01);
    }

    @Test
    public void testGetCapacity() {
        assertEquals(20, activity.getCapacity());
    }

    @Test
    public void testSetCapacity() {
        activity.setCapacity(30);
        assertEquals(30, activity.getCapacity());
    }

    @Test
    public void testIsFull() {
        assertFalse(activity.isFull()); // Initially, not full
        activity.setCapacity(0);
        assertTrue(activity.isFull()); // Capacity is 0, so it's full
    }

    @Test
    public void testDecreaseCapacity() {
        activity.decreaseCapacity();
        assertEquals(19, activity.getCapacity());
        activity.setCapacity(0);
        activity.decreaseCapacity();
        assertEquals(0, activity.getCapacity()); // Should not go below 0
    }
}

