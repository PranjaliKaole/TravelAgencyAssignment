package com.travelAgency;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TravelPackageTest {
	private TravelPackage travelPackage;
	private Destination destination1;
	private Destination destination2;
	private Passenger passenger1;
	private Passenger passenger2;
	private Passenger passenger3;

	@BeforeEach
	public void setUp() {
		// Create instances of TravelPackage, Destination, and Passengers for testing
		travelPackage = new TravelPackage("Beach Vacation", 100);
		destination1 = new Destination("Beach");
		destination2 = new Destination("Mountain");
		passenger1 = new Passenger("Alice", 1, PassengerType.STANDARD, 100.0);
		passenger2 = new Passenger("Bob", 2, PassengerType.GOLD, 200.0);
		passenger3 = new Passenger("Charlie", 3, PassengerType.PREMIUM);

		travelPackage.addDestination(destination1);
		travelPackage.addDestination(destination2);
		travelPackage.addPassenger(passenger1);
		travelPackage.addPassenger(passenger2);
		travelPackage.addPassenger(passenger3);
	}

	@Test
	public void testGetName() {
		assertEquals("Beach Vacation", travelPackage.getName());
	}

	@Test
	public void testSetName() {
		travelPackage.setName("Mountain Retreat");
		assertEquals("Mountain Retreat", travelPackage.getName());
	}

	@Test
	public void testGetPassengerCapacity() {
		assertEquals(100, travelPackage.getPassengerCapacity());
	}

	@Test
	public void testSetPassengerCapacity() {
		travelPackage.setPassengerCapacity(120);
		assertEquals(120, travelPackage.getPassengerCapacity());
	}

	@Test
	public void testGetItinerary() {
		assertEquals(2, travelPackage.getItinerary().size());
	}

	@Test
	public void testSetItinerary() {
		List<Destination> newItinerary = new ArrayList<>();
		newItinerary.add(destination1);
		newItinerary.add(destination2);
		travelPackage.setItinerary(newItinerary);
		assertEquals(2, travelPackage.getItinerary().size());
	}

	@Test
	public void testGetPassengers() {
		assertEquals(3, travelPackage.getPassengers().size());
	}

	@Test
	public void testSetPassengers() {
		List<Passenger> newPassengers = new ArrayList<>();
		newPassengers.add(passenger1);
		newPassengers.add(passenger2);
		travelPackage.setPassengers(newPassengers);
		assertEquals(2, travelPackage.getPassengers().size());
	}

	@Test
	public void testAddDestination() {
		Destination newDestination = new Destination("City Tour");
		travelPackage.addDestination(newDestination);
		assertEquals(3, travelPackage.getItinerary().size());
	}

	@Test
	public void testAddPassenger() {
		Passenger newPassenger = new Passenger("David", 4, PassengerType.STANDARD, 150.0);
		travelPackage.addPassenger(newPassenger);
		assertEquals(4, travelPackage.getPassengers().size());
	}

	@Test
	public void testPrintItinerary() {
		// Redirect system output for testing
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		System.setOut(new PrintStream(outputStream));

		travelPackage.printItinerary();

		// Restore system output
		System.setOut(System.out);

		// Verify the printed output (replace this with the expected output)
		String expectedOutput = "Travel Package: Beach Vacation\n" + "Destination: Beach\n" + "Activity: Hiking\n"
				+ "Description: Explore the trails\n" + "Cost: 20.0\n" + "Capacity: 30\n" + "Destination: Mountain\n"
				+ "Activity: Sightseeing\n" + "Description: City tour\n" + "Cost: 30.0\n" + "Capacity: 20\n";

		assertEquals(expectedOutput, outputStream.toString());
	}

}
