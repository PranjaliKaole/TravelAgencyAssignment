package com.travelAgency;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class DestinationTest {
	private Destination destination;

	@BeforeEach
	public void setUp() {
		// Create a Destination instance for testing
		destination = new Destination("Beach");
	}

	@Test
	public void testGetName() {
		assertEquals("Beach", destination.getName());
	}

	@Test
	public void testSetName() {
		destination.setName("Mountain");
		assertEquals("Mountain", destination.getName());
	}

	@Test
	public void testGetActivities() {
		assertEquals(0, destination.getActivities().size()); // Initially, no activities
	}

	@Test
	public void testSetActivities() {
		List<Activity> activities = new ArrayList<>();
		activities.add(new Activity("Swimming", "Enjoy swimming", 10.0, 50));
		destination.setActivities(activities);

		assertEquals(1, destination.getActivities().size());
		assertEquals("Swimming", destination.getActivities().get(0).getName());
	}

	@Test
	public void testAddActivity() {
		Activity activity = new Activity("Hiking", "Explore the trails", 20.0, 30);
		destination.addActivity(activity);

		assertEquals(1, destination.getActivities().size());
		assertEquals("Hiking", destination.getActivities().get(0).getName());
	}

	@Test
	public void testPrintAvailableActivities() {
		Activity activity1 = new Activity("Snorkeling", "Discover underwater life", 25.0, 40);
		Activity activity2 = new Activity("Surfing", "Ride the waves", 30.0, 20);

		destination.addActivity(activity1);
		destination.addActivity(activity2);

		// Redirect system output for testing
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		System.setOut(new PrintStream(outputStream));

		destination.printAvailableActivities();

		// Restore system output
		System.setOut(System.out);

		String expectedOutput = "Destination Name: Beach\n" + "Activity: Snorkeling\n"
				+ "Description: Discover underwater life\n" + "Cost: 25.0\n" + "Capacity: 40\n" + "Activity: Surfing\n"
				+ "Description: Ride the waves\n" + "Cost: 30.0\n" + "Capacity: 20\n";

		assertEquals(expectedOutput, outputStream.toString());
	}
}
