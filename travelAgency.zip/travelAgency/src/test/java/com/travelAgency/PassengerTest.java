package com.travelAgency;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class PassengerTest {
	private Passenger standardPassenger;
	private Passenger goldPassenger;
	private Passenger premiumPassenger;

	@BeforeEach
	public void setUp() {
		// Create instances of Passenger for testing
		standardPassenger = new Passenger("Alice", 1, PassengerType.STANDARD, 100.0);
		goldPassenger = new Passenger("Bob", 2, PassengerType.GOLD, 200.0);
		premiumPassenger = new Passenger("Charlie", 3, PassengerType.PREMIUM);
	}

	@Test
	public void testGetName() {
		assertEquals("Alice", standardPassenger.getName());
	}

	@Test
	public void testSetName() {
		standardPassenger.setName("Alicia");
		assertEquals("Alicia", standardPassenger.getName());
	}

	@Test
	public void testGetPassengerNumber() {
		assertEquals(1, standardPassenger.getPassengerNumber());
	}

	@Test
	public void testSetPassengerNumber() {
		standardPassenger.setPassengerNumber(11);
		assertEquals(11, standardPassenger.getPassengerNumber());
	}

	@Test
	public void testGetBalance() {
		assertEquals(100.0, standardPassenger.getBalance(), 0.01);
	}

	@Test
	public void testSetBalance() {
		standardPassenger.setBalance(150.0);
		assertEquals(150.0, standardPassenger.getBalance(), 0.01);
	}

	@Test
	public void testGetType() {
		assertEquals(PassengerType.STANDARD, standardPassenger.getType());
	}

	@Test
	public void testSetType() {
		standardPassenger.setType(PassengerType.GOLD);
		assertEquals(PassengerType.GOLD, standardPassenger.getType());
	}

	@Test
	public void testSignUpForActivityStandard() {
		Activity activity = new Activity("Hiking", "Explore the trails", 20.0, 30);
		standardPassenger.signUpForActivity(activity);

		assertEquals(1, standardPassenger.getSignedUpActivities().size());
		assertEquals(80.0, standardPassenger.getBalance(), 0.01);
		assertTrue(activity.isFull());
	}

	@Test
	public void testSignUpForActivityGold() {
		Activity activity = new Activity("Snorkeling", "Discover underwater life", 25.0, 40);
		goldPassenger.signUpForActivity(activity);

		assertEquals(1, goldPassenger.getSignedUpActivities().size());
		assertEquals(190.0, goldPassenger.getBalance(), 0.01);
		assertTrue(activity.isFull());
	}

	@Test
	public void testSignUpForActivityPremium() {
		Activity activity = new Activity("Sightseeing", "City tour", 30.0, 20);
		premiumPassenger.signUpForActivity(activity);

		assertEquals(1, premiumPassenger.getSignedUpActivities().size());
		assertEquals(0.0, premiumPassenger.getBalance(), 0.01);
		assertTrue(activity.isFull());
	}

	@Test
	public void testPrintDetails() {
		// Redirect system output for testing
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		System.setOut(new PrintStream(outputStream));

		standardPassenger.printDetails();

		// Restore system output
		System.setOut(System.out);

		String expectedOutput = "Passenger Name: Alice\n" + "Passenger Number: 1\n" + "Passenger Tpe: STANDARD\n"
				+ "Balance: 100.0\n";

		assertEquals(expectedOutput, outputStream.toString());
	}

}
