package com.travelAgency;

import java.util.ArrayList;
import java.util.List;

public class Destination {

	private String name;

	private List<Activity> activities;

	public Destination(String name) {
		this.name = name;
		activities = new ArrayList<>();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Activity> getActivities() {
		return activities;
	}

	public void setActivities(List<Activity> activities) {
		this.activities = activities;
	}

	public void addActivity(Activity activity) {
		activities.add(activity);
	}

	public void printAvailableActivities() {
		System.out.println("Destination Name: " + name);
		for (Activity activity : getActivities()) {
			System.out.println("Activity: " + activity.getName());
			System.out.println("Description: " + activity.getDescription());
			System.out.println("Cost: " + activity.getCost());
			System.out.println("Capacity: " + activity.getCapacity());
		}
	}

}
