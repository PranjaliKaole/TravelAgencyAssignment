package com.travelAgency;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TravelAgencyApplication {

	public static void main(String[] args) {
		SpringApplication.run(TravelAgencyApplication.class, args);

		Activity activity1 = new Activity("Sightseeing Tour", "Explore the city", 50.0, 20);
		Activity activity2 = new Activity("Hiking Adventure", "Enjoy a mountain hike", 75.0, 15);
		Activity activity3 = new Activity("Beach Relaxation", "Relax by the beach", 25.0, 30);

		// Create destinations and add activities
		Destination destination1 = new Destination("City A");
		Destination destination2 = new Destination("Mountain Town B");
		Destination destination3 = new Destination("Beach Resort C");

		destination1.addActivity(activity1);
		destination2.addActivity(activity2);
		destination3.addActivity(activity3);

		// Create passengers
		Passenger passenger1 = new Passenger("John", 1001, PassengerType.STANDARD, 100.0);
		Passenger passenger2 = new Passenger("Alice", 1002, PassengerType.GOLD, 150.0);
		Passenger passenger3 = new Passenger("Bob", 1003, PassengerType.PREMIUM);

		// Create a travel package and add destinations
		TravelPackage package1 = new TravelPackage("Package X", 50);
		package1.addDestination(destination1);
		package1.addDestination(destination2);
		package1.addDestination(destination3);

		// Sign up passengers for activities
		passenger1.signUpForActivity(activity1);
		passenger2.signUpForActivity(activity2);
		passenger3.signUpForActivity(activity1);
		passenger3.signUpForActivity(activity2);
		passenger3.signUpForActivity(activity3);

		// Print itinerary of the travel package
		package1.printItinerary();

		// Print the passenger list of the travel package
		package1.printPassengerList();

		// Print the details of an individual passenger
		passenger1.printDetails();
		passenger2.printDetails();
		passenger3.printDetails();

		// Print the details of available activities
		destination1.printAvailableActivities();
	}

}
