package com.travelAgency;

public enum PassengerType {
	STANDARD, GOLD, PREMIUM
}
