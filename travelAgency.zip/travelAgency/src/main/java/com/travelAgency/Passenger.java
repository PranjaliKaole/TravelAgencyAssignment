package com.travelAgency;

import java.util.ArrayList;
import java.util.List;

public class Passenger {

	private String name;

	private int passengerNumber;

	private double balance;

	private PassengerType type;

	private List<Activity> signedUpActivities;

	public Passenger(String name, int passengerNumber, PassengerType type, double balance) {
		this(name, passengerNumber, type);
		this.balance = balance;
	}

	public Passenger(String name, int passengerNumber, PassengerType type) {
		this.name = name;
		this.passengerNumber = passengerNumber;
		this.type = type;
		this.signedUpActivities = new ArrayList<>();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPassengerNumber() {
		return passengerNumber;
	}

	public void setPassengerNumber(int passengerNumber) {
		this.passengerNumber = passengerNumber;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public PassengerType getType() {
		return type;
	}

	public void setType(PassengerType type) {
		this.type = type;
	}

	public List<Activity> getSignedUpActivities() {
		return signedUpActivities;
	}

	public void setSignedUpActivities(List<Activity> signedUpActivities) {
		this.signedUpActivities = signedUpActivities;
	}
	
    public void signUpForActivity(Activity activity) {
        if (type == PassengerType.STANDARD) {
            if (balance >= activity.getCost()) {
                balance -= activity.getCost();
            } else {
                System.out.println("Insufficient balance for activity sign-up.");
                return;
            }
        } else if (type == PassengerType.GOLD) {
            double discountedCost = 0.9 * activity.getCost();
            if (balance >= discountedCost) {
                balance -= discountedCost;
            } else {
                System.out.println("Insufficient balance for activity sign-up.");
                return;
            }
        }

        signedUpActivities.add(activity);
        activity.decreaseCapacity();
    }

	public void printDetails() {
		System.out.println("Passenger Name: " + this.name);
		System.out.println("Passenger Number: " + this.passengerNumber);
		System.out.println("Passenger Tpe: " + this.type);
		if (this.type != PassengerType.PREMIUM) {
			System.out.println("Balance: " + this.balance);
		}
	}

}
